import React from 'react'

export default function Navbar() {
  return (
    <div>Navbar</div>
  )
}
