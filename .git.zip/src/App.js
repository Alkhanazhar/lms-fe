import React from "react";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Navigate,
  useLocation,
} from "react-router-dom";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import NotFound from "./pages/NotFound";
import 'bootstrap/dist/css/bootstrap.min.css';
import Signup from "./pages/SignUp";
import ForgetPassword from "./pages/ForgetPassword";
import Profile from "./pages/Profile";
import Discover from "./pages/Discover";
import Settings from "./pages/Settings";
import Pricing from "./pages/Pricing";

import AdminTeacher from "./pages/AdminTeacher";
import AdminStudents from "./pages/AdminStudents";
import AdminCourses from "./pages/AdminCourses";
import SuperAdminSchool from "./pages/SuperAdminSchool";
import SuperAdminDashboard from "./pages/SuperAdminDashboard";
import SuperAdminCourses from "./pages/SuperAdminCourses";
import AdminDashboard from "./pages/AdminDashboard";
import TeacherDashboard from "./pages/TeacherDashboard";
import TeacherCourses from "./pages/TeacherCourses";
// function ProtectedRoute({ children, allowedRoles }) {
//   const location = useLocation();
//   const role = localStorage.getItem("role");

//   if (!role) {
//     return <Navigate to="/login" state={{ from: location }} />;
//   }

//   if (!allowedRoles.includes(role)) {
//     return <Navigate to="/login" state={{ from: location }} />;
//   }

//   return children;
// }
const role = "admin";

localStorage.setItem("role", role);

function ProtectedRoute({ children, allowedRoles }) {
  const location = useLocation();
  const role = localStorage.getItem("role");
  if (!role || !allowedRoles.includes(role)) {
    return <Navigate to="/not-found" state={{ from: location }} />;
  }

  return children;
}


export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/forget-password" element={<ForgetPassword />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/search" element={<Discover />} />
        <Route path="/search/:id" element={<Discover />} />
        {/* <Route path="/search/:searchText" element={<SearchPage />} /> */}
        <Route path="/settings" element={<Settings />} />
        <Route path="/pricing" element={<Pricing />} />
        {/* Superadmin Routes */}
        <Route
          path="/superadmin/*"
          element={
            <ProtectedRoute allowedRoles={["superadmin"]}>
              <Routes>
                <Route path="/" element={<Dashboard />} >
                  {/* Add more parent routes here if needed */}
                  <Route path="" element={<SuperAdminDashboard />} />
                  <Route path="schools" element={<SuperAdminSchool />} />
                  <Route path="courses" element={<SuperAdminCourses />} />
                </Route>
              </Routes>
            </ProtectedRoute>
          }
        />
        {/* Parent Routes */}
        <Route
          path="/admin/*"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              {/* <ProtectedRoute allowedRoles={["parent"]}> */}
              <Routes>
                <Route path="/" element={<Dashboard />} >
                  {/* Add more parent routes here if needed */}
                  <Route path="" element={<AdminDashboard />} />
                  <Route path="teachers" element={<AdminTeacher />} />
                  <Route path="students" element={<AdminStudents />} />
                  <Route path="courses" element={<AdminCourses />} />
                </Route>
              </Routes>
            </ProtectedRoute>}
        />
        {/* Employee Routes */}
        <Route
          path="/teacher/*"
          element={
            <ProtectedRoute allowedRoles={["teacher"]}>
              <Routes>
                <Route path="/" element={<Dashboard />} >
                  {/* Add more parent routes here if needed */}
                  <Route path="" element={<TeacherDashboard />} />
                  <Route path="courses" element={<TeacherCourses />} />
                </Route>
              </Routes>
            </ProtectedRoute>
          }
        />
        <Route
          path="/student/*"
          element={
            <ProtectedRoute allowedRoles={["student"]}>
              <Routes>
                <Route path="/" element={<Dashboard />} />
                {/* Add more employee routes here if needed */}
              </Routes>
            </ProtectedRoute>
          }
        />
        <Route
          path="/child/*"
          element={
            <ProtectedRoute allowedRoles={["child"]}>
              <Routes>
                <Route path="/" element={<Dashboard />} />
              </Routes>
            </ProtectedRoute>
          }
        />

        {/* Default Route */}
        <Route path="/" element={<Navigate to="/login" />} />
        <Route path="/not-found" element={<NotFound />} />
        <Route path="*" element={<Navigate to="/not-found" />} />
      </Routes>
    </Router>
  );
}
