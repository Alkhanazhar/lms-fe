export const BASE_URL = "http://localhost:8080/api";

export const LOGIN = "/login" 
export const REGISTER = "/register" 
export const GET_DATA = "/get_data" 