import React from 'react'

const TeacherCourses = () => {
  return (
    <div>TeacherCourses</div>
  )
}

export default TeacherCourses