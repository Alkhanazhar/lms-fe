import React from "react";
import { Link, Outlet, useLocation } from "react-router-dom";
import { School, Users, Book, FileText } from 'lucide-react'; // Import Lucide icons

const DashboardLayout = () => {
  const location = useLocation();
  const role = localStorage.getItem('role');

  // Sidebar Links based on Role with Icons
  const navLinks = {
    superadmin: [
      { path: "/superadmin/school", name: "School", icon: <School className="icon-size" /> },
      { path: "/superadmin/teachers", name: "Teachers", icon: <Users /> },
      { path: "/superadmin/students", name: "Students", icon: <Users /> },
    ],
    admin: [
      { path: "/admin/teachers", name: "Teachers", icon: <Users /> },
      { path: "/admin/students", name: "Students", icon: <Users /> },
      { path: "/admin/courses", name: "Courses", icon: <Book /> },
    ],
    teacher: [
      { path: "/teacher/courses", name: "Courses", icon: <Book /> },
    ],
  };

  const linksToDisplay = navLinks[role] || [];
  return (
    <div className="container-fluid">
      <div className="row">
        {/* Sidebar */}
        <div className="col-12 col-md-3 col-lg-2 bg-light sidebar d-flex flex-column p-3">
          <h3 className="text-center">Dashboard</h3>
          <ul className="nav flex-column">
            {linksToDisplay.map((link, index) => (
              <li key={index} >
                <Link
                  to={link.path}
                  className={`nav-link d-flex align-items-center ${location.pathname === link.path ? "bg-black text-white" : "text-black"}`}
                >
                  <span className="me-2 ">{link.icon}</span> {/* Add icon */}
                  {link.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div className="col-12 col-md-9 col-lg-10">
          <div className="p-4">
            <Outlet />
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardLayout;
