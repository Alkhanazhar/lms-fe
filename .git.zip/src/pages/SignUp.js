import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useForm } from "react-hook-form";
import { EyeIcon, EyeOff } from "lucide-react"
import Button from "../include/Button";

function Signup() {
  const [showPassword, setShowPassword] = useState(false)
  const { register, formState: { errors }, handleSubmit } = useForm()
  const handleShowPassword = () => {
    setShowPassword((prev) => !prev)
  }
  const onSubmit = (data) => {
    console.log(data);
  };
  return (
    <div className="relative ">
      <div className="container-fluid">
        <div className="row justify-content-center align-items-center ">
          <div className="col-12 col-lg-3 d-flex flex-column login-center-div shadow-lg align-items-center justify-content-center p-4">
            <h2 className="login-form-title text-center mb-2 fw-bold fs-2">Welcome</h2>
            <div className="form-heading ">
              <p >Sign up to LMS.</p>
            </div>
            {/* Your content goes here */}
            <form onSubmit={handleSubmit(onSubmit)} className="w-100">
              {/* Email */}
              <div className="mb-3">
                <input
                  type="email"
                  className="form-control login-form-input"
                  id="email"
                  {...register("email", {
                    required: "Email is required",
                    pattern: {
                      value: /^[^@ ]+@[^@ ]+\.[^@ .]{2,}$/,
                      message: "Email is not valid"
                    }
                  })}
                  placeholder="Email"
                />
                {errors.email && <p className="text-danger errorFormHandler">{errors.email.message}</p>}
              </div>

              {/* Password */}
              <div className="row">
                <div className="col-md-12 position-relative">
                  <input
                    type={showPassword ? "password" : "text"}
                    className="form-control login-form-input"
                    id="password"
                    {...register("password", {
                      required: "Password is required",
                      minLength: {
                        value: 6,
                        message: "Password must be at least 6 characters long"
                      }
                    })}
                    placeholder="Password"
                  />
                  <div className="eye-icon" onClick={handleShowPassword}>
                    {showPassword ? <EyeIcon /> : <EyeOff />}
                  </div>

                </div>
                {errors.password && <p className="text-danger errorFormHandler">{errors.password.message}</p>}
              </div>
              {/* Submit Button */}
              <div className="d-grid mt-2">
                <Button type="submit"  >Sign up</Button>
              </div>
              <p className="mt-2 text-center already-account">
                Already have an Account <Link to={"/login"}>Login</Link>  </p>
              <div className="text-center mt-4 mb-4 position-relative">
                <hr className="my-4" />
                <span className="position-absolute top-50 start-50 translate-middle bg-white px-3 subFormText">
                  or
                </span>
              </div>
              <div className="d-flex flex-column align-items-center btn-login-group">
                <button type="button" className="btn w-100">Continue with Google</button>
                <button type="button" className="btn w-100 ">Continue with Facebook</button>
                <button type="button" className="btn w-100">Continue with Apple</button>
              </div>
            </form>

          </div>
        </div>
      </div>
    </div>
  );
}

export default Signup;
