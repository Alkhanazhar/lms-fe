import React from 'react'

const SuperAdminDashboard = () => {
  return (
    <div>SuperAdminDashboard</div>
  )
}

export default SuperAdminDashboard

