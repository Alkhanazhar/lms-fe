import React from 'react'

const SuperAdminSchool = () => {
  return (
    <div>SuperAdminSchool</div>
  )
}

export default SuperAdminSchool