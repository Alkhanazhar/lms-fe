
const ProfileAndAccount = () => {
    return (
        <div>ProfileAndAccount</div>
    )
}
export default ProfileAndAccount