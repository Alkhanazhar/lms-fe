import React from 'react'

const Pricing = () => {
    return (
        <>







        </>
    )
}

export default Pricing