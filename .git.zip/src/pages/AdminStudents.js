import React from 'react'

const AdminStudents = () => {
  return (
    <div>AdminStudents</div>
  )
}

export default AdminStudents