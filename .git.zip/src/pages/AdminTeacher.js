
const AdminTeacher = () => {
  return (
    <div>AdminTeacher</div>
  )
}

export default AdminTeacher