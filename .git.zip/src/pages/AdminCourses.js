import React from 'react'

const AdminCourses = () => {
  return (
    <div>AdminCourses</div>
  )
}

export default AdminCourses