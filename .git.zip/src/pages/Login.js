import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useForm } from "react-hook-form";
import Button from "../include/Button";
import { EyeIcon, EyeOff } from "lucide-react"


function Login() {

  const { register, formState: { errors }, handleSubmit } = useForm()
  const [showPassword, setShowPassword] = useState(false)
  const handleShowPassword = () => {
    setShowPassword((prev) => !prev)
  }
  const onSubmit = (data) => {
    console.log(data);
  };
  return (
    <div className="relative ">
      {/* <img src="https://images.unsplash.com/photo-1584697964328-b1e7f63dca95?q=80&w=1740&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="login-form" className="login-form-image" /> */}
      <div className="container-fluid ">
        <div className="row justify-content-center align-items-center ">
          <div className="col-12 col-lg-3 d-flex flex-column login-center-div shadow-lg align-items-center justify-content-center p-4">
            <h2 className="login-form-title text-center mb-2 fs-2 fw-bolder">Welcome</h2>
            <div className="form-heading ">
              <p >Log in to LMS.</p>
            </div>
            {/* Your content goes here */}
            <form onSubmit={handleSubmit(onSubmit)} className="w-100">
              {/* Email */}
              <div className="mb-3">
                <input
                  type="email"
                  className="form-control login-form-input"
                  id="email"
                  {...register("email", {
                    required: "Email is required",
                    pattern: {
                      value: /^[^@ ]+@[^@ ]+\.[^@ .]{2,}$/,
                      message: "Email is not valid"
                    }
                  })}
                  placeholder="Email"
                />
                {errors.email && <p className="text-danger errorFormHandler">{errors.email.message}</p>}
              </div>

              {/* Password */}
              <div className="row">
                <div className="col-md-12 position-relative">
                  <input
                    type={showPassword ? "password" : "text"}
                    className="form-control login-form-input"
                    id="password"
                    {...register("password", {
                      required: "Password is required",
                      minLength: {
                        value: 6,
                        message: "Password must be at least 6 characters long"
                      }
                    })}
                    placeholder="Password"
                  />
                  <div className="eye-icon" onClick={handleShowPassword}>
                    {showPassword ? <EyeIcon /> : <EyeOff />}
                  </div>
                 
                </div>
                {errors.password && <p className="text-danger errorFormHandler">{errors.password.message}</p>}
                <div className="mt-2">

                  <Link to="/forget-password" className="forget-password ">Forget password?</Link>
                </div>
              </div>
              {/* Submit Button */}
              <div className="d-grid">
                <Button type="submit" >Sign In</Button>
              </div>
              <p className="mt-2 text-center already-account">
                Don't have an Account <Link to={"/signup"}>signup</Link>  </p>
              <div className="text-center mt-4 mb-4 position-relative">
                <hr className="my-4" />
                <span className="position-absolute top-50 start-50 translate-middle bg-white px-3 subFormText">
                  or
                </span>
              </div>
              <div className="d-flex flex-column align-items-center btn-login-group">
                <button type="button" className="btn w-100">Continue with Google</button>
                <button type="button" className="btn w-100 ">Continue with Facebook</button>
                <button type="button" className="btn w-100">Continue with Apple</button>
              </div>
            </form>

          </div>
        </div>
      </div>
    </div>
  );
}

export default Login;
