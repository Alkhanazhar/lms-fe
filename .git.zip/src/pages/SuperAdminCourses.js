import React from 'react'

const SuperAdminCourses = () => {
  return (
    <div>SuperAdminCourses</div>
  )
}

export default SuperAdminCourses