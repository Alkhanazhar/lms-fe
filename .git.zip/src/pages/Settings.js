import { useState } from "react"
import RadioFilter from "../include/RadioFilter";
const Settings = () => {
    const handleCategorySwitch = (id) => setSelectedCategory(id);
    const categoryData = [{
        id: 1,
        title: "View Profile",
        element: <ViewProfile />
    },
    {
        id: 2,
        title: "Profile Settings",
        element: <ProfileSettings />
    },
    {
        id: 3,
        title: "Password",
        element: <Password />
    },
    {
        id: 4,
        title: "Payment and Membership",
        element: <PaymentMembership />
    },
    {
        id: 5,
        title: "Email Address",
        element: <EmailAddress />
    },
    ]
    const [selectedCategory, setSelectedCategory] = useState(categoryData[0]);
    return (
        <div className="container-fluid row mx-auto g-4 row ">
            <div className="my-5 w-75 col-3 mx-auto">
                <h1 className="main-heading">Settings</h1>
                <div className="w-100 position-relative mt-4">
                    <div className="absolute d-flex gap-3 border-bottom">
                        {categoryData.map((category, index) => (
                            <button
                                key={index}
                                onClick={() => handleCategorySwitch(category)}
                                className={`p-3 fw-700 switch-btn  ${selectedCategory.id === category.id ? "switch-border switch-btn-color" : "switch-border-unActive"}`}
                            >{category.title}
                            </button>
                        ))}
                    </div>
                </div>
                <div className="mt-4 col-12 ">
                    {selectedCategory.element}
                </div>
            </div>
        </div>
    )
}

export default Settings

const ProfileSettings = () => {
    const classTypes = [
        { id: 'type1', value: 'private', label: 'Make my profile private' },
        { id: 'type2', value: 'away from search results', label: 'Remove my profile from search results' },
    ];
    const [selectedType, setSelectedType] = useState('');
    const handleTypeChange = (event) => {
        setSelectedType(event.target.value);
    };
    return <div className="w-100 border bg-white">
        <h1 className="fs-2 fw-bolder  p-4 lh-1 border-bottom">Profile Settings</h1>
        <div className="p-4 mt-2">
            <h5 className="fw-bolder">Username</h5>
            <input type="text" className="form-control w-50" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" placeholder="Your username" />
            <div className="row">
                <div className="col-12 col-md-6 mt-4">
                    <RadioFilter
                        options={classTypes}
                        name="classType"
                        selectedValue={selectedType}
                        onChange={handleTypeChange}
                        title="Privacy"
                    />
                </div>
            </div>
            <button className="btn-small-list rounded-1 px-4 py-1">Save Changes</button>
        </div>
    </div>
}
const Password = () => {
    return <div className="w-100 border bg-white">
        <h1 className="fs-2 fw-bolder p-4 lh-1 border-bottom">Password</h1>
        <div className="p-4">
            <h6>We will send a verification link to <strong>your_email@gmail.com.</strong> This update will not take place until you follow the instructions listed in that email.If you do not have access to <strong>your_email@gmail.com.</strong>, please contact support for assistance.</h6>
            <button className="btn-small-list rounded-1 px-4 py-1 mt-3">Reset Password</button>
        </div>
    </div>
}
const ViewProfile = () => {

    let name = "Azure Aghan"

    const categoryData = [{
        id: 1,
        title: "Profile",
        element: <About name={name} />
    },
    {
        id: 2,
        title: "Achivement",
        element: <Achivement />
    },
    ]
    const [selectedCategory, setSelectedCategory] = useState(categoryData[0]);
    const handleCategorySwitch = (id) => setSelectedCategory(id);
    return <div className="w-100 ">
        {/* <h1 className="fs-2 fw-bolder lh-1  p-4">Profile</h1> */}
        <div >
            <div className="row">
                <div className="col-12 col-md-6 col-lg-3 p-4 d-flex flex-column justify-content-start align-items-center">
                    <img src="https://static.skillshare.com/assets/images/default-profile-2020.jpg" alt="profile" className="rounded-pill w-75" />
                    <h2 className="mt-3 fw-bolder">{name}</h2>
                    <em className="d-none d-md-block">Add Headline</em>
                    <em className="mt-2 w-100 border-bottom pb-3 text-center d-none d-md-block">Link personal website</em>
                    <div className="row pt-3 pb-3 border-bottom w-100">
                        <div className="col-6 d-flex flex-column">
                            <div className="mx-auto mb-2">_ _</div>
                            <h6 className="text-center">Followers</h6>
                        </div>
                        <div className="col-6 d-flex flex-column">
                            <div className="mx-auto mb-2">_ _</div>

                            <h6 className="text-center">Following</h6>

                        </div>
                    </div>
                    <em className="mt-2 w-100  pb-3 text-center">Link Social Links</em>
                </div>

                <div className="col-12 col-md-6 col-lg-9">

                    <div className="w-100 position-relative ">
                        <div className="absolute d-flex gap-3 border-bottom ">
                            {categoryData.map((category) => (
                                <button
                                    key={category.id}
                                    onClick={() => handleCategorySwitch(category)}
                                    className={`p-3 w-100 fw-semibold switch-btn  ${selectedCategory.id === category.id ? "switch-border switch-btn-color" : "switch-border-unActive"
                                        }`}
                                >{category.title}
                                </button>
                            ))}
                        </div>
                    </div>
                    <div className="mt-4 col-12 p-2 h-100 ">
                        {selectedCategory.element}
                    </div>
                </div>
            </div>
        </div>
    </div >
}
const PaymentMembership = () => {
    return <div className="w-100 border bg-white">
        <h1 className="fs-2 fw-bolder p-4 lh-1 border-bottom">Payment and Membership</h1>
        <div className="p-4">

        </div>
    </div>
}

const EmailAddress = () => {
    const classTypes = [
        { id: 'type1', value: 'private', label: 'Make my profile private' },
        { id: 'type2', value: 'away from search results', label: 'Remove my profile from search results' },
    ];
    const [selectedType, setSelectedType] = useState('');
    const handleTypeChange = (event) => {
        setSelectedType(event.target.value);
    };
    return <div className="w-100 border bg-white">
        <h1 className="fs-2 fw-bolder p-4 lh-1 border-bottom">Email Address</h1>
        <div className="p-4">
            <div><h5 className="fw-bolder">Current Email Address</h5>
                <input type="text" className="form-control w-50" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" placeholder="Your username" />
            </div>
            <div className="mt-3">

                <h5 className="fw-bolder">New Email Address</h5>
                <input type="text" className="form-control w-50" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" placeholder="Your username" />
            </div>
            <div className="mt-3">

                <h5 className="fw-bolder">Confirm New Email Address</h5>
                <input type="text" className="form-control w-50" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" placeholder="Your username" />
            </div>

            <button className="btn-small-list rounded-1 px-4 py-1 mt-3">Update Email</button>
            <h6 className="fw-bolder mt-4">
                We have received a request to change the email address associated with your account in the LMS  system. To confirm this change, please click the link below:

                [Confirm Email Change Link]

                For added security, we have sent a confirmation OTP to your current email address. Please enter the OTP to proceed with updating your email address.
            </h6>
        </div>
    </div>
}

const About = ({ name }) => {
    let about = null;
    return <div>
        <h1 className="fw-bolder">About Us</h1>
        <div>
            {about ? <h6>
                {about}
            </h6> : <h6>Hello ,I am {name}</h6>}
        </div>
    </div>
}
const Achivement = () => {
    const achievements = [
        {
            name: "Lifetime", card: [
                "Complete a Class",
                "Submit a Project",
            ]
        },
        {
            name: "Milestone", card: [
                "Save a Class",
                "Complete 3 Classes",
                "Complete 5 Classes",
                "Complete 10 Classes",
                "Complete 25 Classes",
                "Complete 50 Classes",
                "Complete 100 Classes",
                "Submit 3 Projects",
                "Submit 10 Projects",
                "Submit 25 Projects",
                "Submit 50 Projects",
                "Submit 100 Projects",
            ]
        },
        {
            name: "Community", card: [
                "Follow a Teacher",
                "Give Feedback",
                "Start Discussion",
                "Review a Class",
            ]
        },

    ]
    return <div>
        <h1 className="fw-bolder">Achivement Us</h1>
        <h3 className="fw-bolder mt-4" >Certificates</h3>
        <p>Earn a class certificate by completing a class and submitting a project.<strong> FAQ about Certificates.</strong></p>
        <div className="dotted-border rounded-3 p-4">
            <h5 className="text-center fw-bolder">You haven't earned a certificate yet.</h5>
            <h4 className="text-center">Complete a class and submit a project to get your first class certificate.</h4>
            <div className="d-flex justify-content-center align-items-center mt-4">
                <button className="btn btn-dark-outline">Find a Class</button>
            </div>
        </div>
        <div className="mt-4">
            {achievements.map((item, index) => (
                <div className="mt-4" key={index}>
                    <h4 className="fw-bolder mb-3">{item.name}</h4>
                    <div className="row g-4">
                        {item.card.map((cardItem, index) => (
                            <div key={index} className="col-12 col-md-6 col-lg-6 col-xl-4 ">
                                <div className="card acheivements-card border rounded-3 shadow-sm">
                                    <div className="card-body cursor-pointer d-flex align-items-center flex-column justify-content-center">
                                        <img src="https://static.skillshare.com/assets/images/rewards/badges/incomplete/submit_a_project.svg" alt="card-acheivements" className="" />
                                        <div className="text-center card-text mx-auto ">

                                            {cardItem}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            ))}
        </div>

    </div>
}

